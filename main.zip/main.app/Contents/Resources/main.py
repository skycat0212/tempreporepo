

import os
import sys
# sys.path.append('/path/to')
from openpyxl import Workbook
from openpyxl import load_workbook

# print(sys.version)
# print(sys.path)

print("[TEST] start ================================================================")

# 1. 거래내역 파일을 열기
# 2. 거래내역 시트 열기
# 3. 거래내역을 읽는다
#       G열의 cell.value == "내용" 인 행의 다음 행부터 거래 내역의 내용이 있음

# 거래 내용을 목록화 한다.
#       거래 금액이 10000원인 것들과 아닌 것들을 구분한다.
#       id 대용의 식별자가 필요할 경우 거래일시를 사용하자. (입금여부 확인에 거래 일시를 함께 명시해도 좋을 듯)

# 추가로 처리해줘야 할 사항
#   동명이인인 경우가 있을 수 있음


current_dir = os.path.dirname(__file__)
desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')
basic_path = os.path.join(desktop_path, 'resource/')


class BankSheet:
    bank_wb = load_workbook(basic_path + "카카오뱅크_거래내역.xlsx")
    bank_ws = bank_wb['카카오뱅크 거래내역']

    def __init__(self):
        return
    
    # 거래내역
    # 리턴 값은 거래내역의 내용 셀의 리스트
    def get_transactions(self):
        cells = self.bank_ws['G']
        transactions = []
        is_transaction = False
        for cell in cells:
            if cell.value == "내용":
                is_transaction = True
                continue
            elif is_transaction:
                transactions.append(cell)
        return transactions

    # 파라미터 : 분류하려는 거래내역 내용 셀 리스트
    # 반환 : (10,000원 입금자 리스트, 그 외 내역 리스트)
    def get_regular_depositor(self, transactions):
        regular_deposit_transactions = []
        etc_deposit_transactions = []
        for transaction in transactions:
            row = transaction.row
            deposit_cell = self.bank_ws["D" + str(row)]
            if deposit_cell.value == "10,000":
                regular_deposit_transactions.append(transaction)
            else:
                etc_deposit_transactions.append(transaction)
        return (regular_deposit_transactions, etc_deposit_transactions)

class AppliantSheet:
    appliant_wb = load_workbook(basic_path + "플로깅 신청.xlsx")
    appliant_ws = appliant_wb['설문지 응답 시트1']
    status_ws = None

    # 신청 타임스탬프 : A열
    apply_timestamp_list_row = 1
    # 신청자 명단 : B열
    appliant_list_row = 2
    # 입금 타임스탬프 : E열
    deposit_timestamp_list_row = 3
    # 입금자명 : C열
    depositor_list_row = 4
    # 입금 여부 : D열
    deposit_status_list_row = 5

    # 동명 신청 타임스탬프 : K열
    same_name_apply_timestamp_list_row = 11
    # 동명 신청자 명단 : L열
    same_name_appliant_list_row = 12

    # 신청 미반영 입금 타임스탬프 : P열
    non_reflected_deposit_timestamp_list_row = 16
    # 신청 미반영 입금자명 : Q열
    non_reflected_depositor_list_row = 17
    # 신청 미반영 거래금액 : R열
    non_reflected_deposit_amout_list_row = 18

    def __init__(self):
        if "신청자 현황" in self.appliant_wb.sheetnames:
            # 이미 존재하는 시트인 경우 가져오기
            self.status_ws = self.appliant_wb["신청자 현황"]
        else:
            # 존재하지 않는 경우 새로운 시트 생성
            self.status_ws = self.appliant_wb.create_sheet(title="신청자 현황")
            self.appliant_wb.save(basic_path + "플로깅 신청.xlsx")

        self.status_ws.cell(1, self.appliant_list_row, "신청자 명단")
        self.status_ws.cell(1, self.apply_timestamp_list_row, "신청 타임스탬프")
        self.status_ws.cell(1, self.depositor_list_row, "입금자명")
        self.status_ws.cell(1, self.deposit_status_list_row, "입금 여부")
        self.status_ws.cell(1, self.deposit_timestamp_list_row, "입금 타임스탬프")

        self.status_ws.cell(1, self.same_name_appliant_list_row, "동명 신청자 명단")
        self.status_ws.cell(1, self.same_name_apply_timestamp_list_row, "동명 신청 타임스탬프")

        self.status_ws.cell(1, self.non_reflected_depositor_list_row, "신청 미반영 입금자명")
        self.status_ws.cell(1, self.non_reflected_deposit_timestamp_list_row, "신청 미반영 입금 타임스탬프")
        self.status_ws.cell(1, self.non_reflected_deposit_amout_list_row, "신청 미반영 거래금액")

        self.appliant_wb.save(basic_path + "플로깅 신청.xlsx")

    def get_appliant_name_cells(self):
        return self.appliant_ws["B"][1:]
    
    def get_appliant_names(self):
        return list(map(lambda cell: (cell.value), self.get_appliant_name_cells()))
    
    # (동명이인 없는 목록, 동명이인 있는 목록)
    def get_appliant_name_cells_without_same_name(self):
        cells = self.get_appliant_name_cells()
        names = self.get_appliant_names()
        single_cells = []
        duplicated_cells = []
        for cell in cells:
            if names.count(cell.value) == 1:
                single_cells.append(cell)
            elif names.count(cell.value) > 1:
                duplicated_cells.append(cell)
        return (single_cells, duplicated_cells)

# 거래내역
bank_sheet = BankSheet()
deposits = bank_sheet.get_transactions()
(regular_depositor, etc_depositor) = bank_sheet.get_regular_depositor(deposits)

# 신청 내역
appliant_sheet = AppliantSheet()
status_sheet_offset_row = 2
status_sheet_offset_column = "A"
appliant_name_cells = appliant_sheet.get_appliant_name_cells()
appliant_names = appliant_sheet.get_appliant_names()
(appliant_single_name_cells, appliant_duplicated_name_cells) = appliant_sheet.get_appliant_name_cells_without_same_name()

# 동명 신청자 명단을 위한 임시 변수
same_name_cell_row = 2
# 신청 미반영 거래내역을 위한 임시 변수
non_reflected_deposit_row = 2

for name_cell in appliant_name_cells:

    apply_timestamp = appliant_sheet.appliant_ws["A"+str(name_cell.row)].value
    appliant_sheet.status_ws.cell(status_sheet_offset_row, appliant_sheet.apply_timestamp_list_row, apply_timestamp)

    name = name_cell.value
    appliant_sheet.status_ws.cell(status_sheet_offset_row, appliant_sheet.appliant_list_row, name)


    # 신청자 중 동명이인 여부
    is_single_appliant_name = False
    if appliant_names.count(name) == 1:
        is_single_appliant_name = True

    # 정상 입금자 목록
    regular_depositor_name_list = list(map(lambda cell: cell.value, regular_depositor))

    # 신청자가 동명이인이 아닐 때
    if is_single_appliant_name:
        # 입금자 목록에 없을 때 - 신청 1 : 입금 0
        if regular_depositor_name_list.count(name) == 0:
            None
        # 입금자 목록에 해당 이름이 1개 올라가 있을 때 - 신청 1 : 입금 1
        elif regular_depositor_name_list.count(name) == 1:
            bank_sheet_row = list(filter(lambda cell: cell.value == name, regular_depositor))[0].row
            depositor_name = bank_sheet.bank_ws["G" + str(bank_sheet_row)].value
            deposit_timestamp = bank_sheet.bank_ws["B" + str(bank_sheet_row)].value

            appliant_sheet.status_ws.cell(status_sheet_offset_row, appliant_sheet.depositor_list_row, depositor_name)
            appliant_sheet.status_ws.cell(status_sheet_offset_row, appliant_sheet.deposit_status_list_row, "O")
            appliant_sheet.status_ws.cell(status_sheet_offset_row, appliant_sheet.deposit_timestamp_list_row, deposit_timestamp)
        # 입금자 목록에 해당 이름이 여러개 올라가 있을 때 - 신청 1 : 입금 N
        elif regular_depositor_name_list.count(name) > 1:
            appliant_sheet.status_ws.cell(status_sheet_offset_row, appliant_sheet.deposit_status_list_row, "동명 입금 2건 이상")

    # 신청자가 동명이인일 때
    elif not is_single_appliant_name:
        appliant_sheet.status_ws.cell(status_sheet_offset_row, appliant_sheet.deposit_status_list_row, "동명 신청자 존재")

        appliant_sheet.status_ws.cell(same_name_cell_row, appliant_sheet.same_name_appliant_list_row, name)
        appliant_sheet.status_ws.cell(same_name_cell_row, appliant_sheet.same_name_apply_timestamp_list_row, apply_timestamp)
        
        same_name_cell_row += 1

    status_sheet_offset_row += 1

for deposit in deposits:
    bank_sheet_row = deposit.row
    deposit_timestamp = bank_sheet.bank_ws["B" + str(bank_sheet_row)].value
    depositor_name = bank_sheet.bank_ws["G" + str(bank_sheet_row)].value
    amount = bank_sheet.bank_ws["D" + str(bank_sheet_row)].value

    status_saved_timestamp_cells = appliant_sheet.status_ws['C']
    if len(list(filter(lambda cell: cell.value == deposit_timestamp, status_saved_timestamp_cells))) == 0:
        appliant_sheet.status_ws.cell(non_reflected_deposit_row, appliant_sheet.non_reflected_depositor_list_row, depositor_name)
        appliant_sheet.status_ws.cell(non_reflected_deposit_row, appliant_sheet.non_reflected_deposit_timestamp_list_row, deposit_timestamp)
        appliant_sheet.status_ws.cell(non_reflected_deposit_row, appliant_sheet.non_reflected_deposit_amout_list_row, amount)
    
        non_reflected_deposit_row += 1

appliant_sheet.appliant_wb.save(basic_path + "플로깅 신청.xlsx")




print("[TEST] end ================================================================")

# ----------------------------------------------------------------
# ================================================================